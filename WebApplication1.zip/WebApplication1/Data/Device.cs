﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Data
{
  public class Device
  {
    private DeviceStates _deviceState;

    [Display(Name = "Device State Since")]
    public DateTime? DeviceStateSince { get; set; }

    [Display(Name = "Device state")]
    public DeviceStates DeviceState
    {
      get
      {
        return _deviceState;
      }
      set
      { //only update on devicestate changes 
        //TODO Thingk about this, if this is ok to only update when a state changes to OK ,Missing or Lampfailure; state changes to overtemp etc. are discarded
        if (value != _deviceState && (value.HasFlag(DeviceStates.Ok) || !IsDeviceStateOk()))
        {
          DeviceStateSince = DateTime.UtcNow;
        }
        _deviceState = value;
      }
    }

    public virtual bool IsDeviceStateOk()
    {
      return !DeviceState.HasFlag(DeviceStates.Disabled) &&
        !DeviceState.HasFlag(DeviceStates.Missing) &&
        !DeviceState.HasFlag(DeviceStates.LampFailure) &&
        !DeviceState.HasFlag(DeviceStates.Faulty);
    }
  }
}
